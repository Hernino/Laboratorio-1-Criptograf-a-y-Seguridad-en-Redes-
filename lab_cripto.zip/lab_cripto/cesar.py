import sys

def cifrar_cesar(texto: str, corrimiento: int) -> str:
    resultado = []
    for char in texto:
        if 'a' <= char <= 'z':
            nuevo_char = chr((ord(char) - ord('a') + corrimiento) % 26 + ord('a'))
            resultado.append(nuevo_char)
        elif 'A' <= char <= 'Z':
            nuevo_char = chr((ord(char) - ord('A') + corrimiento) % 26 + ord('A'))
            resultado.append(nuevo_char)
        else:
            resultado.append(char)
    return "".join(resultado)

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Uso: sudo python3 cesar.py \"<texto>\" <desplazamiento>")
        sys.exit(1)

    texto_origen = sys.argv[1]
    desplazamiento = int(sys.argv[2])
    texto_cifrado = cifrar_cesar(texto_origen, desplazamiento)
    print(texto_cifrado)
