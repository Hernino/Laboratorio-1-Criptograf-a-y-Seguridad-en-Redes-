import sys
import time
from scapy.all import IP, ICMP, send

def enviar_paquetes_icmp(mensaje: str, ip_destino: str = "127.0.0.1"):
    # Payload estándar base de ping en Linux (48 bytes)
    payload_base = bytes(range(0x10, 0x38))
    
    for i, char in enumerate(mensaje):
        # Insertar el carácter al inicio del payload
        datos = char.encode('utf-8') + payload_base[1:]
        
        paquete = IP(dst=ip_destino) / ICMP(type=8, id=0x0001, seq=i+1) / datos
        send(paquete, verbose=False)
        print("Sent 1 packets.")
        time.sleep(0.05)

    if mensaje:
        print(f"El último carácter del mensaje se transmite como una {mensaje[-1]}.")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Uso: sudo python3 pingv4.py \"<mensaje_cifrado>\" [ip_destino]")
        sys.exit(1)

    mensaje_cifrado = sys.argv[1]
    destino = sys.argv[2] if len(sys.argv) > 2 else "127.0.0.1"
    enviar_paquetes_icmp(mensaje_cifrado, destino)
