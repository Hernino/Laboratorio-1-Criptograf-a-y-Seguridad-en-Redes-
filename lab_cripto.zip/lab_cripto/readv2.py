import sys
from scapy.all import rdpcap, ICMP

# Frecuencia relativa porcentual de letras en el idioma español
FRECUENCIAS_ESP = {
    'e': 13.68, 'a': 12.53, 'o': 8.68, 's': 7.98, 'r': 6.87,
    'n': 6.71,  'i': 6.25,  'd': 5.86, 'l': 4.97, 'c': 4.68,
    't': 4.63,  'u': 3.93,  'm': 3.15, 'p': 2.51, 'b': 1.42,
    'g': 1.01,  'v': 0.90,  'y': 0.90, 'q': 0.88, 'h': 0.70,
    'f': 0.69,  'z': 0.52,  'j': 0.44, 'x': 0.22, 'w': 0.01, 'k': 0.01
}

def descifrar_cesar(texto: str, corrimiento: int) -> str:
    resultado = []
    for char in texto:
        if 'a' <= char <= 'z':
            resultado.append(chr((ord(char) - ord('a') - corrimiento) % 26 + ord('a')))
        elif 'A' <= char <= 'Z':
            resultado.append(chr((ord(char) - ord('A') - corrimiento) % 26 + ord('A')))
        else:
            resultado.append(char)
    return "".join(resultado)

def calcular_puntaje_frecuencia(texto: str) -> float:
    # Suma los pesos estadísticos de cada letra encontrada
    puntaje = 0.0
    for char in texto.lower():
        puntaje += FRECUENCIAS_ESP.get(char, 0.0)
    return puntaje

def procesar_captura(pcap_path: str):
    paquetes = rdpcap(pcap_path)
    caracteres = []

    for pkt in paquetes:
        if pkt.haslayer(ICMP) and pkt[ICMP].type == 8:
            raw_data = bytes(pkt[ICMP].payload)
            if raw_data:
                caracteres.append(chr(raw_data[0]))

    mensaje_interceptado = "".join(caracteres)
    print(f"\n{mensaje_interceptado}\n")

    # Evaluar los 25 desplazamientos
    candidatos = []
    for shift in range(1, 26):
        texto_candidato = descifrar_cesar(mensaje_interceptado, shift)
        score = calcular_puntaje_frecuencia(texto_candidato)
        candidatos.append((shift, texto_candidato, score))

    # Identificar la frase con mayor probabilidad estadística
    mejor_opcion = max(candidatos, key=lambda x: x[2])

    # Imprimir lista con el formato exacto de la guía
    for shift, texto, _ in candidatos:
        if shift == mejor_opcion[0]:
            print(f"\033[92m{texto}\t{shift}\033[0m")
        else:
            print(f"{texto}\t{shift}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Uso: sudo python3 readv2.py <archivo.pcapng>")
        sys.exit(1)

    procesar_captura(sys.argv[1])
